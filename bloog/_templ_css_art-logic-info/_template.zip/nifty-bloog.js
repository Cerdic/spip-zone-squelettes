window.onload=function(){
Nifty("div.boite,div.avatar,div.reponse,div.discussion,p.interne");
Nifty("ul#minipics li,div.grande_boite,div#content,div#footer");
Nifty("div#container","big");
Nifty("div#header","top,big");
Nifty("ul#deco h4,ul#decobas h4,ul#nav li","top");
Nifty("div#surcontent","bottom,big");
Nifty("#cel p","bottom,same-height");
Nifty("#celbas p","bottom");
}
